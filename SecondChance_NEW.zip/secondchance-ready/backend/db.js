import { MongoClient } from 'mongodb';
const client = new MongoClient(process.env.MONGODB_URI || 'mongodb://localhost:27017');
let db;
export async function connectToDatabase() {
  if (!db) { await client.connect(); db = client.db(process.env.DB_NAME || 'secondchance'); }
  return db;
}
export async function closeDatabase() { await client.close(); db = undefined; }
