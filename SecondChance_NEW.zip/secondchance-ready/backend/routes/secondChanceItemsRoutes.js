import { Router } from 'express';
import { ObjectId } from 'mongodb';
import multer from 'multer';
import { connectToDatabase } from '../db.js';
import { requireAuth } from './authRoutes.js';
export const secondChanceItemsRoutes = Router();
const upload = multer({storage:multer.memoryStorage(),limits:{fileSize:2*1024*1024},fileFilter:(req,file,cb)=>cb(null,file.mimetype.startsWith('image/'))});
secondChanceItemsRoutes.get('/',async(req,res,next)=>{try{const db=await connectToDatabase();res.json(await db.collection('items').find().limit(100).toArray());}catch(e){next(e)}});
secondChanceItemsRoutes.get('/:id',async(req,res,next)=>{try{
 if(!ObjectId.isValid(req.params.id))return res.status(400).json({error:'Invalid ID'});
 const db=await connectToDatabase();const item=await db.collection('items').findOne({_id:new ObjectId(req.params.id)});
 item?res.json(item):res.status(404).json({error:'Not found'});
}catch(e){next(e)}});
secondChanceItemsRoutes.post('/',requireAuth,upload.single('image'),async(req,res,next)=>{try{
 const {title,description,category}=req.body;
 if(!title||!category)return res.status(400).json({error:'Title and category required'});
 const item={title,description:description||'',category,ownerId:req.user.id,createdAt:new Date()};
 if(req.file)item.image={mimeType:req.file.mimetype,data:req.file.buffer.toString('base64')};
 const db=await connectToDatabase();const result=await db.collection('items').insertOne(item);
 res.status(201).json({...item,_id:result.insertedId});
}catch(e){next(e)}});
secondChanceItemsRoutes.delete('/:id',requireAuth,async(req,res,next)=>{try{
 if(!ObjectId.isValid(req.params.id))return res.status(400).json({error:'Invalid ID'});
 const db=await connectToDatabase();const result=await db.collection('items').deleteOne({_id:new ObjectId(req.params.id),ownerId:req.user.id});
 result.deletedCount?res.json({message:'Deleted'}):res.status(404).json({error:'Not found or not owned'});
}catch(e){next(e)}});
