import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { ObjectId } from 'mongodb';
import { connectToDatabase } from '../db.js';
export const authRoutes = Router();
const secret = () => process.env.JWT_SECRET;
export function requireAuth(req,res,next) {
  try { const token = (req.headers.authorization || '').replace(/^Bearer /i,''); req.user = jwt.verify(token,secret()); next(); }
  catch { res.status(401).json({error:'Authentication required'}); }
}
authRoutes.post('/register',async(req,res,next)=>{try{
 const {name,email,password}=req.body;
 if(!name||!email||!password||password.length<8)return res.status(400).json({error:'Name, email and password (8+ chars) required'});
 const db=await connectToDatabase(); const normalized=email.trim().toLowerCase();
 if(await db.collection('users').findOne({email:normalized}))return res.status(409).json({error:'Email already registered'});
 const result=await db.collection('users').insertOne({name,email:normalized,passwordHash:await bcrypt.hash(password,12)});
 res.status(201).json({message:'Registered',userId:String(result.insertedId)});
}catch(e){next(e)}});
authRoutes.post('/login',async(req,res,next)=>{try{
 const db=await connectToDatabase(); const user=await db.collection('users').findOne({email:String(req.body.email||'').trim().toLowerCase()});
 if(!user||!await bcrypt.compare(String(req.body.password||''),user.passwordHash))return res.status(401).json({error:'Invalid credentials'});
 res.json({token:jwt.sign({id:String(user._id)},secret(),{expiresIn:'2h'}),name:user.name});
}catch(e){next(e)}});
authRoutes.put('/me',requireAuth,async(req,res,next)=>{try{
 const name=String(req.body.name||'').trim(); if(!name)return res.status(400).json({error:'Name required'});
 const db=await connectToDatabase();await db.collection('users').updateOne({_id:new ObjectId(req.user.id)},{$set:{name}});
 res.json({message:'Updated',name});
}catch(e){next(e)}});
