import { Router } from 'express';
import { connectToDatabase } from '../db.js';
export const searchRoutes = Router();
searchRoutes.get('/',async(req,res,next)=>{try{
 const db=await connectToDatabase();const filter={};
 if(req.query.category)filter.category=String(req.query.category);
 if(req.query.q)filter.title={$regex:String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),$options:'i'};
 res.json(await db.collection('items').find(filter).limit(100).toArray());
}catch(e){next(e)}});
