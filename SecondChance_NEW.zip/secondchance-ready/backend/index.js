import natural from 'natural';
import { Router } from 'express';
export const sentimentRoutes=Router();
const analyzer=new natural.SentimentAnalyzer('English',natural.PorterStemmer,'afinn');
sentimentRoutes.post('/',(req,res)=>{const text=String(req.body.text||'');res.json({score:analyzer.getSentiment(new natural.WordTokenizer().tokenize(text))});});
