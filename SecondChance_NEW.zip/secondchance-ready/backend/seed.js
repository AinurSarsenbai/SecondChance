import 'dotenv/config';
import {connectToDatabase,closeDatabase} from './db.js';
const categories=['Furniture','Electronics','Kitchen','Books'];
const names=['Chair','Lamp','Table','Sofa','Monitor','Keyboard','Radio','Phone stand','Plates','Kettle','Mugs','Pan','Novel','Textbook','Dictionary','Comics'];
try {const db=await connectToDatabase();const items=names.map((title,i)=>({title,description:`Free pre-loved ${title.toLowerCase()}`,category:categories[Math.floor(i/4)],ownerId:'seed',createdAt:new Date()}));
const result=await db.collection('items').insertMany(items);console.log('inserted_items:',result.insertedCount);console.log(JSON.stringify(result.insertedIds,null,2));}
finally{await closeDatabase();}
