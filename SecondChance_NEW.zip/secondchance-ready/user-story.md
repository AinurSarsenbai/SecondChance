# User Story Template
**As a** [type of user], **I want** [feature], **so that** [benefit].

## Acceptance criteria
- Given [context], when [action], then [outcome].

## Priority
Backlog / New / Icebox / Technical debt
