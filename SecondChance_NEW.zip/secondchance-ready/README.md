# SecondChance
A free household-item sharing platform. Node.js/Express/MongoDB backend and React frontend.

## Run locally
1. `docker compose up --build` (requires Docker).
2. Visit http://localhost:5173; API at http://localhost:3000.
3. Seed 16 items: `docker compose exec backend node seed.js`.
4. Copy `.env.example` to `.env` if running backend outside Docker.

## API
- GET `/api/secondchance/items`, `/api/secondchance/items/:id`
- POST `/api/secondchance/items` (multipart form with optional image, title, description, category; requires Bearer token)
- DELETE `/api/secondchance/items/:id` (Bearer token, item owner)
- GET `/api/secondchance/search?category=Furniture&q=chair`
- POST `/api/secondchance/auth/register`, `/login`; PUT `/me` with Bearer token
- POST `/api/secondchance/sentiment` with JSON `{ "text": "great item" }`

## Coursera evidence
Use actual public GitHub file links for tasks 1,4–9. Create eight GitHub Issues using `docs/issues.md` and label each as instructed; screenshot Issues page for task 2. Run `node seed.js` and save terminal output as `inserted_items` for task 3. Deploy app and screenshot its landing page with URL visible for task 10. Run examples from `docs/curl-examples.md` against your running deployment and save real command/output for tasks 11–15. Screenshot or copy successful GitHub Actions run for task 16. Do not submit sample placeholders as real evidence.
