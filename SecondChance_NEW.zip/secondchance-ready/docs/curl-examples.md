# Run these against your real running server
Replace localhost with your deployment URL if deployed. Copy actual terminal output, not placeholders.

## mainpage
```sh
curl -i http://localhost:3000/api/secondchance/items
```
## register
```sh
curl -i -X POST http://localhost:3000/api/secondchance/auth/register -H 'Content-Type: application/json' -d '{"name":"Demo User","email":"demo@example.com","password":"SecureDemo123!"}'
```
## login
```sh
curl -i -X POST http://localhost:3000/api/secondchance/auth/login -H 'Content-Type: application/json' -d '{"email":"demo@example.com","password":"SecureDemo123!"}'
```
## item_detail
Get an `_id` from the mainpage output, then:
```sh
curl -i http://localhost:3000/api/secondchance/items/REPLACE_ITEM_ID
```
## search_item
```sh
curl -i 'http://localhost:3000/api/secondchance/search?category=Furniture'
```
