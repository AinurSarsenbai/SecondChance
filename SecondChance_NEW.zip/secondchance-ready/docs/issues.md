# Create these as eight real GitHub Issues
Apply the label in parentheses (create labels in repository Settings if needed).

1. Register an account (new): As a visitor, I want to register so I can share items.
2. Login securely (new): As a user, I want to log in so I can manage my items.
3. Browse all items (backlog): As a visitor, I want to see free items so I can discover offers.
4. Filter by category (backlog): As a visitor, I want to filter items so I can find relevant things.
5. Upload an item photo (new): As a donor, I want to attach a photo so recipients know what I offer.
6. Delete my listing (backlog): As a donor, I want to remove my listing when an item is gone.
7. Add item reviews (icebox): As a recipient, I want to review an item so others can trust the listing.
8. Improve API test coverage (technical debt): As a developer, I want automated API tests so regressions are caught.
